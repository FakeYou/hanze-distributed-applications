package nl.hanze.web.gba;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;
import nl.hanze.web.gba.domain.*;

public class GBA extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action=readAction(request);
        if ("get".equals(action)) {
            // dummy implementation
            NatuurlijkPersoon np=new NatuurlijkPersoon();
            np.setBsn(123456789);
            np.setGeslacht('v');
            np.setInitialen("RX");
            
            // return json format
            request.setAttribute("np", np);
            RequestDispatcher view=request.getRequestDispatcher("get.jsp");
            view.forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    private String readAction(HttpServletRequest request) {
        return request.getParameter("action");
    }
}
