package nl.hanze.web.gba.domain;

public class NatuurlijkPersoon {
    private long bsn;
    private char geslacht;
    private String initialen;

    /**
     * @return the bsn
     */
    public long getBsn() {
        return bsn;
    }

    /**
     * @param bsn the bsn to set
     */
    public void setBsn(long bsn) {
        this.bsn = bsn;
    }

    /**
     * @return the geslacht
     */
    public char getGeslacht() {
        return geslacht;
    }

    /**
     * @param geslacht the geslacht to set
     */
    public void setGeslacht(char geslacht) {
        this.geslacht = geslacht;
    }

    /**
     * @return the initialen
     */
    public String getInitialen() {
        return initialen;
    }

    /**
     * @param initialen the initialen to set
     */
    public void setInitialen(String initialen) {
        this.initialen = initialen;
    }

    
    
    
}
